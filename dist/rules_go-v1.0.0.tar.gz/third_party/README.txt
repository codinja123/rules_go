This directory contains patches for repositories declared by
go_rules_dependencies.

If you declare dependencies on different versions of these repositories, you
may need to update and apply these patches yourself.

For details on overriding dependencies, see
https://github.com/bazelbuild/rules_go/blob/master/go/dependencies.rst#overriding-dependencies

For details on updating these patches, see
https://github.com/bazelbuild/rules_go/wiki/Updating-dependencies
