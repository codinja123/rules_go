go_download_sdk
===============

go_download_sdk_test
--------------------
Verifies that ``go_downlaod_sdk`` can be used to download a specific version
or a set of archives for various platforms.
