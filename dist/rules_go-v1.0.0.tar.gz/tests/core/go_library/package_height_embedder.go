package embed

var X = T{}
