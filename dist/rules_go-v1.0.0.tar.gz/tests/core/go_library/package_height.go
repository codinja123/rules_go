package height

import "package_height/embed"
import "package_height/dep"

var X = embed.T{F: dep.T{}}
