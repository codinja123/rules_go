package platform_lib

const Platform = "linux"
