go_proto_library importmap
==========================

importmap_test
--------------

Checks that the ``importmap`` attribute of ``go_proto_library`` works correctly.
The test uses reflection information for a type in the generated file.
