#include <stdio.h>

void foo() {
  printf("foo\n");
}

 
