go_bazel_test macro functionality
=================================

Tests to ensure the go_bazel_test is functioning correctly.

dataargtest_test
----------------

Tests that `data` and `args` provided to `go_bazel_test` are provided to the go
test framework correctly.
