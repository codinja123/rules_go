package cgo_trans_deps

import "C"

import _ "github.com/bazelbuild/rules_go/tests/cgo_trans_deps/dep"
