Legacy tests
============

This is all the tests that were written before we became structured about
testing methodology.

They are mostly useful, but need restructuring, breaking up and documenting
before adding to the main test suite.

Help in here is very welcome!