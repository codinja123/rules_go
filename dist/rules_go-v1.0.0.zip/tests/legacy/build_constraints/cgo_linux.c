const char* cgoC = "linux";
