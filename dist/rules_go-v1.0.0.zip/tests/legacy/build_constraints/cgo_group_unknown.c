// +build !linux

const char* cgoCGroup = "unknown";
