package foo

func foo() int32
