#ifndef split_import_c
#define split_import_c

int half(int);

#endif
