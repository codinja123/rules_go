#include "add.h"

#if !defined(RULES_GO_CPP) || !defined(RULES_GO_CXX) || defined(RULES_GO_C)
#error This is an Objective-C++ file, only RULES_GO_CXX and RULES_GO_CPP should be defined.
#endif
