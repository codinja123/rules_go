package main

var Embed = "redacted"
