// +build !good

package lib

var Does Not = Compile
