// +build cgo

// This file will not compile and its inclusion in a build is used to ensure
// that a binary was built in pure mode.
package main

import "non/existent/pkg"
