Starlark unit tests
=======================

common_test_suite
---------

Checks that ``has_shared_lib_extension`` from ``//go/private:common.bzl``
correctly matches shared library filenames, which may optionally have a version
number at the end.
